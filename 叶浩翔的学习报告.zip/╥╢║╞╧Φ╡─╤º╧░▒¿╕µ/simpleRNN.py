import pandas as pd
import jieba
import re
import tensorflow as tf
from keras.preprocessing.text import Tokenizer
from keras_preprocessing.sequence import pad_sequences
from keras.models import Sequential
from keras.layers import Embedding, SimpleRNN, Dense
"加载数据并用jieba分词进行分词"
with open('C:/Users\86198\Desktop/news_train.csv', 'r', encoding='gbk', errors='ignore') as f:
    data=pd.read_csv(f, header=None, sep=',')
"去除非中文"
def remove_non_chinese(text):
    chinese_pattern = re.compile(r'[\u4e00-\u9fa5]+')
    chinese_text = "".join(chinese_pattern.findall(text))
    return chinese_text
data[1] = data[1].apply(remove_non_chinese)
data[1] = data[1].apply(lambda x: " ".join(jieba.cut(str(x))))
texts = data[1].values
labels = data[0].values.astype('int32')
print(labels)
"将文本转化为序列并进行填充, 取最常见的1000个词,即过滤掉没用的词"
tokenizer = Tokenizer(num_words=1000)
tokenizer.fit_on_texts(texts)
sequences = tokenizer.texts_to_sequences(texts)
padded_sequences = pad_sequences(sequences, maxlen=200)
"创建一个简单的RNN模型"
model = Sequential()
model.add(Embedding(input_dim=10000, output_dim=300, input_length=200))
model.add(SimpleRNN(units=128))
model.add(Dense(units=11, activation='softmax'))
"训练模型"
model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
"将标签值转化为独热编码"
one_hot_labels = tf.keras.utils.to_categorical(labels, num_classes=max(labels)+1)
model.fit(padded_sequences, one_hot_labels, epochs=10, batch_size=32, validation_split=0)