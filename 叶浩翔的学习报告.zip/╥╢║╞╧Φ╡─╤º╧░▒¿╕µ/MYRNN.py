import pandas as pd
import jieba
import re
import tensorflow as tf
from tensorflow import keras
from keras.preprocessing.text import Tokenizer
from keras_preprocessing.sequence import pad_sequences
from keras.models import Sequential
from keras.layers import Embedding, Dense, LSTM, MultiHeadAttention
from keras import regularizers
"读取数据"
with open('C:/Users\86198\Desktop/news_train.csv', 'r', encoding='gbk', errors='ignore') as f:
    data=pd.read_csv(f, header=None, sep=',')
"去除非中文"
def remove_non_chinese(text):
    chinese_model=re.compile(r'[\u4e00-\u9fa5]+')
    chinese_text = "".join(chinese_model.findall(text))
    return chinese_text
data[1] = data[1].apply(remove_non_chinese)
"用结巴分词进行分词"
data[1] = data[1].apply(lambda x: " ".join(jieba.cut(str(x))))
"提取数据中的文本信息和标签"
texts = data[1].values
labels = data[0].values.astype('int32')
"将分词后的单词转换成序列，只保留出现频率前1500的单词"
tokenizer = Tokenizer(num_words=1500)
tokenizer.fit_on_texts(texts)
"将文本映射到序列库中，并填充文本序列至最大长度200"
sequences = tokenizer.texts_to_sequences(texts)
padded_sequences = pad_sequences(sequences, maxlen=200)
"自定义一个继承keras.layers.Layer的MYRNN类"
class MYRNN(keras.layers.Layer):
    def __init__(self, units, num_heads, regularizer=None):
        super(MYRNN, self).__init__()
        self.units = units
        self.num_heads = num_heads
        self.LSTM = LSTM(units, kernel_regularizer=regularizer, return_sequences=True)
        self.attention = MultiHeadAttention(num_heads=num_heads, key_dim=units//num_heads)
    def call(self, inputs):
        LSTM_output = self.LSTM(inputs)
        attention_output = self.attention(LSTM_output, LSTM_output)
        return attention_output
"定义模型"
model = Sequential()
"词嵌入层，将文本序列转化为词向量"
model.add(Embedding(input_dim=10000, output_dim=500, input_length=200))
"应用MYRNN类"
model.add(MYRNN(units=128, num_heads=10, regularizer=regularizers.l2(0.01)))
"改变向量维度，以便兼容后面的运算"
model.add(keras.layers.GlobalAveragePooling1D())
"输出层"
model.add(Dense(11, activation='softmax'))
"设置损失函数和优化器"
model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
"将标签换成独热编码"
one_hot_labels = tf.keras.utils.to_categorical(labels, num_classes=max(labels) + 1)
"训练模型"
model.fit(padded_sequences, one_hot_labels, epochs=10, batch_size=32, validation_split=0)