import numpy as np
import pandas as pd

def grandient(X, y, lr, time):
    m, n = X.shape
    X = (X - np.mean(X, axis=0)) / (np.std(X, axis=0)+1e-10)
    theta = np.zeros((n, 1))
    b=0
    for i in range(time):
        y_pred = X.dot(theta)+b
        loss = y_pred - y
        gradient = (1 / m) * X.T.dot(loss)
        theta = theta - lr * gradient
        b=b-lr*np.sum(loss)/m
        cost = (1 / (2 * m)) * np.sum(np.square(loss))
    return theta,b, cost
data = pd.read_csv('C:/Users\86198\Desktop\叶浩翔的线性回归/train data.csv', sep=',')
num_features = data.shape[1] - 1
X = data.iloc[:, :num_features].values
y = data.iloc[:, num_features].values.reshape(-1, 1)
lr = 0.1
time = 1000
theta,b,cost_history = grandient(X, y, lr, time)
print(theta,b)
print(cost_history)
X = (X - np.mean(X, axis=0)) / (np.std(X, axis=0)+1e-10)
y_new=X.dot(theta)+b
print(y_new)