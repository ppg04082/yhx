import numpy as np
import pandas as pd
"""加载数据"""
data = pd.read_csv('C:/Users/86198/Desktop/train1.csv', header=None)
X = data.iloc[:, :-1].values
y = data.iloc[:, -1].values.reshape(-1, 1)
"""确定类别数和特征数"""
num_classes = 10
theta = X.shape[1]
"""归一化"""
X_mean = np.mean(X, axis=0)
X_std = np.std(X, axis=0)
X = (X - X_mean) / (X_std+1e-10)
"""设置参数"""
W = np.zeros((theta, num_classes))
b = np.zeros((1, num_classes))
"""softmax模型"""
def softmax(z):
    exp_z = np.exp(z - np.max(z, axis=1, keepdims=True))
    y_pred = exp_z / (np.sum(exp_z, axis=1, keepdims=True) + 1e-8)
    return y_pred

time = 1000
lr = 0.01
"""主体"""
for i in range(time):
    z = np.dot(X, W) + b
    y_pred = softmax(z)
    """这个print是测试程序是否正常运行，考虑到有时分母为0导致程序终止却没有报错，强烈建议不要删除"""
    print(y_pred)
    """将y变成独热编码"""
    y_onehot = np.zeros((y.shape[0], num_classes))
    y_onehot[np.arange(y.shape[0]), y.flatten()] = 1
    """损失函数"""
    loss = y_pred - y_onehot
    dW = np.dot(X.T, loss)
    db = np.sum(loss)
    W -= lr * dW
    b -= lr * db
"""加载新的数据"""
data = pd.read_csv('C:/Users/86198/Desktop/test_no_answer.csv', header=None)
X_new = data.iloc[:, :-1].values
X_new = (X_new - X_mean) / (X_std+1e-9)
new_error = np.dot(X_new, W) + b
new_probs = softmax(new_error)
new_preds = np.argmax(new_probs, axis=1)
"""输出数据"""
print(new_probs)
print(new_preds)
df = pd.DataFrame(new_preds)
path='C:/Users/86198/Desktop/result1.xlsx'
df.to_excel(path, index=False)